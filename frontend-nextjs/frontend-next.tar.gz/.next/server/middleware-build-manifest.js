globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c048590c2fa6dd33.js",
    "static/chunks/112f346e31f991df.js",
    "static/chunks/3a677a9a12f3461c.js",
    "static/chunks/023d923a37d494fc.js",
    "static/chunks/c389c39885fb2676.js",
    "static/chunks/turbopack-95262e7d697f8448.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];