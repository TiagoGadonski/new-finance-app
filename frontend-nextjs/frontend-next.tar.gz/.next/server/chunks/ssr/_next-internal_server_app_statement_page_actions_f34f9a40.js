module.exports=[62371,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_statement_page_actions_f34f9a40.js.map