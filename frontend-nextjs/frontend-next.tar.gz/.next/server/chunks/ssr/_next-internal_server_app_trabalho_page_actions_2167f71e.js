module.exports=[45261,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_trabalho_page_actions_2167f71e.js.map