module.exports=[76188,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_splits_page_actions_4a4c7ba1.js.map