module.exports=[1326,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_shopping-lists_%5Bid%5D_page_actions_b7d9b1a4.js.map