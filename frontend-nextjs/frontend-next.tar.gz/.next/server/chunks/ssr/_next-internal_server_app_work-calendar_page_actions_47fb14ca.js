module.exports=[49095,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_work-calendar_page_actions_47fb14ca.js.map